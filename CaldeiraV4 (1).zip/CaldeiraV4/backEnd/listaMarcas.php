<?php
session_start();
include('function.php');

listaMarcas();

?>