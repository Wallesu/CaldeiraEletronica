<?php
    
    session_start();
    include('function.php');

    solicita_orcamento();


?>